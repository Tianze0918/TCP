// Steps:
//  1. Initialize a send and receive buffer.
    // send buffer: a dynamically adjusted buffer to store packets in between last acknowledged packet and last formed packet from stdin
    // receive buffer: a fixed buffer of size 40*MAX_PAYLOAD


#include "consts.h"
#include "io.h"
#include "transport.h"
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>







int main(int argc, char** argv) {
    if (argc < 3) {
        fprintf(stderr, "Usage: client <hostname> <port> \n");
        exit(1);
    }


    /* Create sockets */
    int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    // use IPv4  use UDP

    /* Construct server address */
    struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET; // use IPv4
    // Only supports localhost as a hostname, but that's all we'll test on
    const char* addr = strcmp(argv[1], "localhost") == 0 ? "127.0.0.1" : argv[1];
    server_addr.sin_addr.s_addr = inet_addr(addr);
    // Set sending port
    int PORT = atoi(argv[2]);
    server_addr.sin_port = htons(PORT); // Big endian



    //Setting non-blocking socket, stdin done in init_io()
    int flags = fcntl(sockfd, F_GETFL);                 //Retrieves file status flag for a given file decriptor
    flags |= O_NONBLOCK;                                //Setting flag to be non-blocking
    fcntl(sockfd, F_SETFL, flags);                      //Saving the changed file status flag for a given file descriptor


    init_io();




    listen_loop(sockfd, &server_addr, CLIENT, input_io, output_io);

    return 0;
}
